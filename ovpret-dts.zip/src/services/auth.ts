import type { AppUser } from '../types'
import {
  auth, db, signInWithEmailAndPassword, signOut,
  doc, getDoc, setDoc, serverTimestamp, createAuthUserSafely,
} from './firebase'

export async function loginUser(email: string, password: string): Promise<AppUser> {
  const cred = await signInWithEmailAndPassword(auth, email, password)
  const snap = await getDoc(doc(db, 'users', cred.user.uid))
  if (!snap.exists()) throw new Error('User profile not found. Contact your administrator.')
  const data = snap.data()
  if (data.status === 'pending') throw new Error('Your account is pending approval. Please wait for the administrator to approve your request.')
  if (data.status === 'rejected') throw new Error('Your account registration was rejected. Contact the administrator.')
  if (!data.isActive) throw new Error('Your account has been deactivated. Contact the administrator.')
  return {
    uid:         cred.user.uid,
    email:       cred.user.email!,
    displayName: data.displayName || cred.user.displayName || email,
    role:        data.role,
    department:  data.department,
  }
}

export async function registerUser(data: {
  email: string; password: string; displayName: string; department: string
}): Promise<void> {
  // Create Firebase Auth user
  const uid = await createAuthUserSafely(data.email, data.password)
  // Write Firestore profile with pending status — admin must approve before they can log in
  await setDoc(doc(db, 'users', uid), {
    email: data.email,
    displayName: data.displayName,
    department: data.department,
    role: 'staff',
    isActive: false,
    status: 'pending',
    createdAt: serverTimestamp(),
    createdBy: 'self-registered',
  })
}

export async function logoutUser(): Promise<void> {
  await signOut(auth)
}